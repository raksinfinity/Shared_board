package gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

public class Line extends Shape {

	public Line(int x1, int y1, int x2, int y2, int st, Color color, String text, Font font) {
		super(x1, y1, x2, y2, st, color, "Line", text, font);
	}

	@Override
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(getColor());
		g2.setStroke(new BasicStroke(st));
		Line2D.Double line = new Line2D.Double(x1, y1, x2, y2);
		g2.draw(line);

	}

}
