package gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Rectangle extends Shape {

	public Rectangle(int x1, int y1, int x2, int y2, int st, Color color, String text, Font font) {
		super(x1, y1, x2, y2, st, color, "Rectangle", text, font);
	}

	@Override
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(getColor());
		g2.setStroke(new BasicStroke(st));
		java.awt.Rectangle rectangle = new java.awt.Rectangle(x1, y1, x2 - x1, y2 - y1);
		g2.draw(rectangle);

	}

}
