package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.Serializable;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public abstract class Shape implements Serializable {
	private final String type;
	protected String text;
	protected Font font;
	protected int x1;
	protected int y1;
	protected int x2;
	protected int y2;
	protected int r;
	protected int g;
	protected int b;
	protected int st;

	public Shape(int x1, int y1, int x2, int y2, int st, Color myColor, String type, String text, Font font) {
		setX1(x1);
		setY1(y1);
		setX2(x2);
		setY2(y2);
		this.st = st;
		setColor(myColor);
		this.type = type;
		this.text = text;
		this.font = font;

	}

	public void setX1(int x1) {
		this.x1 = x1;
	}

	public int getX1() {
		return x1;
	}

	public void setX2(int x2) {
		this.x2 = x2;
	}

	public int getX2() {
		return x2;
	}

	public void setY1(int y1) {
		this.y1 = y1;
	}

	public int getY1() {
		return y1;
	}

	public void setY2(int y2) {
		this.y2 = y2;
	}

	public int getY2() {
		return y2;
	}

	public void setColor(Color color) {
		r = color.getRed();
		g = color.getGreen();
		b = color.getBlue();
	}

	public Color getColor() {
		return new Color(r, g, b);
	}

	public String toString() {
		Gson gson = new GsonBuilder().create();
		String result = gson.toJson(this);
		return result;
	}

	public abstract void draw(Graphics g);

}
