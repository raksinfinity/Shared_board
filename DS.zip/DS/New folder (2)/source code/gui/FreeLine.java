package gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

public class FreeLine extends Shape {

	public ArrayList<Integer> X;
	public ArrayList<Integer> Y;

	public FreeLine(ArrayList<Integer> X, ArrayList<Integer> Y, int st, Color color, String text, Font font) {
		super(0, 0, 0, 0, st, color, "FreeLine", text, font);
		this.X = X;
		this.Y = Y;

	}

	public FreeLine(int stroke, Color color, Font font) {

		super(0, 0, 0, 0, stroke, color, "FreeLine", "", font);
		X = new ArrayList<Integer>();
		Y = new ArrayList<Integer>();
		this.st = stroke;
		this.font = font;
	}

	@Override
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(getColor());
		g2.setStroke(new BasicStroke(st));

		// Line2D.Double line = new Line2D.Double(x1, y1, x2, y2);

		for (int i = 1; i < X.size(); i++) {
//    	   g2.drawLine(x1, y1, x2, y2);
			g2.drawLine(X.get(i - 1), Y.get(i - 1), X.get(i), Y.get(i));
		}

	}

}
