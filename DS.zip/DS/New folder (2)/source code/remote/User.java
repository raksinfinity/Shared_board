package remote;

import java.io.Serializable;

public class User implements Serializable {
	// IP and port
	private String ip = "localhost";
	private int port = 8001;
	private String rminame;

	// attributes
	private String name;

	public User(String name, String ip) {
		this.name = name;
		this.ip = ip;
		this.rminame = "RemoteClientGUI_" + name;
	}

	public String get_name() {
		return name;
	}

	public String get_ip() {
		return ip;
	}

	public String get_rminame() {
		return rminame;
	}

}
