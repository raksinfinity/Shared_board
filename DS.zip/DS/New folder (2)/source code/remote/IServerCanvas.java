package remote;

import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import gui.Shape;

public interface IServerCanvas extends Remote {
	public void add(Shape shape) throws RemoteException;
	// public int remove(int id) throws RemoteException;

	public String register(User user) throws RemoteException, NotBoundException;

	public void deregister(User user) throws RemoteException;

	public String get_content() throws RemoteException;

	public void removeLastShape() throws RemoteException;

	public void clearCanvas() throws RemoteException;

	String permission_to_join(String username) throws RemoteException;

	void sendMessage(Message msg) throws RemoteException;

	boolean is_manager(String username) throws RemoteException;

	void kickUser(String manager_username, String username) throws RemoteException;

	void sendNotification(String notification) throws RemoteException;

}
