package remote;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

import gui.Shape;

/**
 * RMI Remote interface - must be shared between client and server. All methods
 * must throw RemoteException. All parameters and return types must be either
 * primitives or Serializable.
 * 
 * Any object that is a remote object must implement this interface. Only those
 * methods specified in a "remote interface" are available remotely.
 */
public interface IRemoteClientGUI extends Remote {

	public void draw(Shape shape, int id) throws RemoteException;

	public String get_content() throws RemoteException;

	void clearCanvas() throws RemoteException;

	void removeLastShape() throws RemoteException;

	void closeCanvas(String info) throws RemoteException;

	public void updateUsersList(ArrayList<String> usersList) throws RemoteException;

	public void recvMessage(Message msg) throws RemoteException;

	public boolean join_popup(String username) throws RemoteException;

	public void recvNotification(String notification) throws RemoteException;

}
