/* Wenzhong Duan, ID 1092454, wenzhongd@student.unimelb.edu.au */
package remote;

import java.io.Serializable;

public class Message implements Serializable {
	public User user;
	public String text;

	public Message(User user, String text) {
		this.user = user;
		this.text = text;
	}

	public String toString() {
		return String.format("{\"user\":\"%s\", \"text\":\"%s\",}", user.toString(), text);
	}

	public String getUserName() {
		return user.get_name();
	}

	public String getText() {
		return text;
	}

}
