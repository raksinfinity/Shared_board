package remote;

import java.rmi.RemoteException;
import java.rmi.NotBoundException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import gui.Shape;

public class ServerCanvas extends UnicastRemoteObject implements IServerCanvas {
	private int current_id;
	private Map<String, IRemoteClientGUI> client_canvases;
	private ArrayList<Shape> shapes;
	private String manager;

	public ServerCanvas(String manager) throws RemoteException {
		current_id = 0;
		client_canvases = new HashMap<String, IRemoteClientGUI>();
		shapes = new ArrayList<Shape>();
		this.manager = manager;
	}

	public synchronized void removeLastShape() throws RemoteException {
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.removeLastShape();
		}
	}

	@Override
	public synchronized void add(Shape shape) throws RemoteException {
			shapes.add(shape);
			drawBroadcast(shape, current_id);
			current_id++;
	}

	@Override
	public synchronized void clearCanvas() throws RemoteException {
		shapes.clear();
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.clearCanvas();
		}
	}

	@Override
	public synchronized void sendMessage(Message msg) throws RemoteException {
		messageBroadcast(msg);
	}

	@Override
	public synchronized void sendNotification(String notification) throws RemoteException {
		notificationBroadcast(notification);
	}

	@Override
	public synchronized String permission_to_join(String username) throws RemoteException {
		if (client_canvases.containsKey(username)) {
			return "Username Exist"; // if contain key, not unique
		}
		if (username.equals(manager)) {
			return "true";
		}
		if (get_manager_canvas().join_popup(username)) {
			if (client_canvases.containsKey(username)) {
				// if two user with the same username asks to join,
				// need to verify if username is unique after the first user is permited
				return "Username Exist";
			} else {
				return "true";
			}
		} else {
			return "The manager refused " + username + " to join.";
		}
	}

	public IRemoteClientGUI get_manager_canvas() {
		return client_canvases.get(manager);
	}

	@Override
	public synchronized boolean is_manager(String username) throws RemoteException {
		return username.equals(manager); // if contain key, not unique
	}

	@Override
	public synchronized String register(User user) throws RemoteException, NotBoundException {
		// Connect to the rmiregistry that is running on localhost
		Registry registry = LocateRegistry.getRegistry(user.get_ip());

		// Retrieve the stub/proxy for the remote math object from the registry
		IRemoteClientGUI clientCanvas = (IRemoteClientGUI) registry.lookup(user.get_rminame());
		client_canvases.put(user.get_name(), clientCanvas);
		//System.out.println("Server: " + user.get_name() + " registered at " + user.get_ip());
		updateUsersListBroadcast();
		return get_content();
	}

	@Override
	public synchronized void deregister(User user) throws RemoteException {
		client_canvases.remove(user.get_name());
		//System.out.println("Server: " + user.get_name() + " Left.");
		updateUsersListBroadcast();
	}

	@Override
	public synchronized void kickUser(String manager_username, String username) throws RemoteException {
		if (!is_manager(manager_username)) {
			return;
		}
		IRemoteClientGUI rc = client_canvases.get(username);
		rc.closeCanvas("You are kicked by the Manager. Further changes on the canvas will not be recorded.");

		client_canvases.remove(username);
		//System.out.println("Server: " + username + " kicked.");
		updateUsersListBroadcast();

	}

	private void drawBroadcast(Shape shape, int id) throws RemoteException {
		// call draw of all users' GUI
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.draw(shape, id);
			//System.out.println(String.format("Server: drawBroadcast to %s: %s ", entry.getKey(), shape.toString()));
		}
	}

	private void updateUsersListBroadcast() throws RemoteException {
		ArrayList<String> usersList = new ArrayList<String>(client_canvases.keySet());
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.updateUsersList(usersList);
			//System.out.println(String.format("Server: updateUsersList to %s", entry.getKey()));
		}
	}

	public void closeBroadcast() throws RemoteException {
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			if (is_manager(entry.getKey())) {
				continue;
			}
			IRemoteClientGUI rc = entry.getValue();
			//System.out.println(String.format("Server: closeBroadcast to %s", entry.getKey()));
			rc.closeCanvas("Server just Left. Further changes on the canvas will not be recorded.");
		}
	}

	private void messageBroadcast(Message msg) throws RemoteException {
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.recvMessage(msg);
			//System.out.println(String.format("Server: messageBroadcast to %s", entry.getKey()));
		}
	}

	public void notificationBroadcast(String notification) throws RemoteException {
		for (Entry<String, IRemoteClientGUI> entry : client_canvases.entrySet()) {
			IRemoteClientGUI rc = entry.getValue();
			rc.recvNotification(notification);
			//System.out.println(String.format("Server: messageBroadcast to %s", entry.getKey()));
		}
	}
	
	@Override
	public synchronized String get_content() throws RemoteException {
		return new Gson().toJson(shapes);
	}

	public synchronized String toString() {
		Gson gson = new GsonBuilder().create();
		String result = gson.toJson(shapes);
		return result;
	}

	

}
