/* Wenzhong Duan, ID 1092454, wenzhongd@student.unimelb.edu.au */
package server;

import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import client.Client;
import remote.ServerCanvas;

public class Server {
	// Declare the port number
	private static String serverIP = "localhost";
	private static String username = "Manager";
	// Identifies the user number connected

//	private Map<String, User> users;

	public static void main(String[] args) {

		if (args.length > 0) {
			if (args.length == 2) {
				try {
					serverIP = args[0];
					username = args[1];
				} catch (NumberFormatException e) {
					System.out.println("usage: java Server <serverIPAddress> username");
					return;
				}
			} else {
				System.out.println("usage: java Server <serverIPAddress> username");
				return;

			}
		}

		ServerCanvas remoteCanvas = run_server();
		if (remoteCanvas == null) {
			System.exit(1);
		}
		run_manager();
		System.out.println("Server run on " + serverIP);

		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() { // unbind before exit
			public void run() {
				try {
					remoteCanvas.closeBroadcast();
					unbindServer();
				} catch (RemoteException e) {
					System.out.println("Remote exception: unbind fail.");

				} catch (NotBoundException e) {
					System.out.println("Not Bound Exception: Servercanvas is not bounded in rmiregistry.");

				}
			}
		}));

	}

	public static ServerCanvas run_server() {
		try {
			System.setProperty("java.rmi.server.hostname",serverIP);

			ServerCanvas remoteCanvas = new ServerCanvas(username);
			// Publish the remote object's stub in the registry under the name "Compute"
			Registry registry = LocateRegistry.getRegistry();
			registry.bind("ServerCanvas", remoteCanvas);
			System.out.println("Server: Canvas server ready");
			return remoteCanvas;
		} catch (AccessException e) {
			System.out.println("Can't start the server. Access Exception. Bind server fail.");
			return null;
		} catch (RemoteException e) {
			System.out.println("Can't start the server. Server cannot be binded to the RMI Registry.");
			return null;
		} catch (AlreadyBoundException e) {
			System.out.println("Can't start the server. ServerCanvas is already bounded.");
			return null;
		}

	}

	public static void run_manager() {
		String clientArgs[] = { serverIP, serverIP, username };
		Client.main(clientArgs);
	}

	private static void unbindServer() throws RemoteException, NotBoundException {
		Registry registry = LocateRegistry.getRegistry();
		registry.unbind("ServerCanvas");
		System.out.println("Server: ServerCanvas unbinded.");
	}

}
