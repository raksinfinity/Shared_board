package client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import client.DrawPanel;
import remote.IServerCanvas;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultCaret;

import com.ozten.font.JFontChooser;
import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Image;
import remote.Message;
import remote.User;
import javax.swing.JScrollPane;

public class ClientGUI extends JFrame {

	public int stroker;
	public int estroker;
	private Color LavenderColor = new Color(230, 230, 250);
	private Color goldColor = new Color(255, 204, 51);
	private Color brownColor = new Color(153, 102, 0);
	private Color purpleColor = new Color(147, 112, 219);
	private Color orangeColor = new Color(255, 140, 0);
	private Color darkgreenColor = new Color(76, 153, 0);
	Font font = new Font("Verdana", Font.BOLD, 15);
	Font fontList = new Font("Verdana", Font.BOLD, 13);

	// Buttons
	// private JButton Newfile;
	private JButton Eraser;
	private JButton ColorChoser;
	private JButton FontChoser;
	private JButton strokeSetter;
	private JButton Line;
	private JButton Oval;
	private JButton Rectangle;
	private JButton FreeLine;
	private JButton Circle;

	private JButton Blue;
	private JButton Red;
	private JButton Green;
	private JButton Yellow;
	private JButton Orange;
	private JButton Pink;
	private JButton Cyan;
	private JButton Gray;
	private JButton Magenta;
	private JButton Dark_gray;
	private JButton Light_gray;
	private JButton Lavender;
	private JButton Gold;
	private JButton Brown;
	private JButton Purple;
	private JButton darkGreenColor;
	private JButton Text;
	private JButton removeShape;

	private JPanel selectionPanel;

	private DrawPanel graphicsPanel;
	private JPanel ColorPanel;

	// clientGUI
	private IServerCanvas serverCanvas;
	private ClientCanvas clientCanvas;
	private User user;

	// buttons
	private JMenuBar menuBar;
	private JButton btnOpen;
	private JButton btnNew;
	private JButton btnSave;
	private JButton btnSaveAs;
	private JButton btnClose;
	private JButton btnSaveAsPNG;
	private JButton btnKick;

	private String openedFilePath;
	private JPanel CanvasPanel;
	private JPanel ChatPanel;
	private JTextField ChatInput;
	private JTextArea UserList;
	private JButton btnSend;
	private JTextArea ChatHistory;
	private JPanel SendPanel;

	private boolean is_manager;
	private ArrayList<String> updateUser;
	private Message chatLog;
	private String notification;
	private JScrollPane UserListPanel;
	private JScrollPane ChatHistoryPanel;
	private JScrollPane NotificationPanel;
	public static JTextArea NotificationArea;

	public void setUpdateUser(ArrayList<String> updateUser) {
		this.updateUser = updateUser;
		UserList.setText("");
		for (String user : ClientGUI.this.updateUser) {
			UserList.append(user + "\n");
		}
		//System.out.println("User List Updated");
	}

	public void setChatlog(Message chatLog) {
		this.chatLog = chatLog;
		String userName = chatLog.getUserName();
		String text = chatLog.getText();
		ChatHistory.append("[" + userName + "] " + text + "\n");
	}

	public void setNotification(String notification) {
		this.notification = notification;
		NotificationArea.setText(notification);
	}

	public ClientGUI(IServerCanvas serverCanvas, boolean is_manager, User user) {
		this.serverCanvas = serverCanvas;
		this.user = user;
		this.is_manager = is_manager;
		createFileMenu();
		createGraphicsPanel(serverCanvas);

		this.setTitle("CODE WARRIORS' Canvas - " + user.get_name());
		this.setSize(1300, 900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.openedFilePath = null;
		this.is_manager = is_manager;
		this.setVisible(true);
		//System.out.println("The Client is Manager? " + is_manager);
	}

	/**
	 * File Menu allow user to save, load, and save as
	 */
	public void createFileMenu() {
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		menuBar.setBackground(Color.pink);

		if (is_manager) {
			btnOpen = new JButton("Open");
			btnOpen.setBackground(Color.pink);
			menuBar.add(btnOpen);
			btnOpen.addActionListener(new loadFile());

			btnNew = new JButton("New");
			btnNew.setBackground(Color.pink);
			menuBar.add(btnNew);
			btnNew.addActionListener(new clearCanvas());

			btnSave = new JButton("Save");
			btnSave.setBackground(Color.pink);
			menuBar.add(btnSave);
			btnSave.addActionListener(new saveFile());

			btnSaveAs = new JButton("Save as");
			btnSaveAs.setBackground(Color.pink);
			menuBar.add(btnSaveAs);
			btnSaveAs.addActionListener(new saveAsFile());

			btnClose = new JButton("Close");
			btnClose.setBackground(Color.pink);
			menuBar.add(btnClose);
			btnClose.addActionListener(new close());
		}

		btnSaveAsPNG = new JButton("Save as PNG");
		btnSaveAsPNG.setBackground(Color.pink);
		menuBar.add(btnSaveAsPNG);
		btnSaveAsPNG.addActionListener(new saveAsPNG());

		if (is_manager) {
			// Kick
			btnKick = new JButton("Kick");
			btnKick.setBackground(Color.pink);
			menuBar.add(btnKick);
			btnKick.addActionListener(new kickPlayer());
		}

	}

	public class saveAsPNG implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			graphicsPanel.saveAsPicture();
			NotificationArea.setText("\nPicture saved to ./output_image.png");

		}

	}// saveAsPNG

	public class drawLine implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

			DrawPanel.draw = 2;

		}

	}// drawLine

	public class setStroke implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			ImageIcon width = new ImageIcon("src/gui/width.png");
			JOptionPane pane = new JOptionPane();
			String s = (String) pane.showInputDialog(null, "Go for it !!!", "Set Thickness", pane.INFORMATION_MESSAGE,
					width, null, "");

			try {

				if (s.equals("")) {
					NotificationArea.setText(
							"\n Error>> Text field cannot be empty. Please, enter a value for thickness i.e (1,2,..)");
				}

				else {
					stroker = Integer.parseInt(s);
					if (stroker == (int) stroker) {
						DrawPanel.stroke = stroker;
					}

					else {
						NotificationArea.setText(
								"\n Error>> Invalid value is entered.  Please, enter a legal value i.e (1,2,..) ");
					}
				}

			} catch (NumberFormatException e) {
				NotificationArea
						.append("\n Error>> Invalid value is entered.  Please, enter a legal value i.e (1,2,..)");
			}

			catch (Exception e) {
				NotificationArea.setText("\n Error>> Thickness is not selected. Please, enter a value i.e (1,2,..)");
			}

		}

	}

	public class removeLastShape implements ActionListener {

		public void actionPerformed(ActionEvent event) {
			try {
				graphicsPanel.removeLastShapeServer();
			} catch (NullPointerException e) {
				NotificationArea.setText("\nError>> You are kicked from the server.");
			} catch (RemoteException e) {
				NotificationArea.setText("\nError>> Connection problem.");
			}
		}
	}// removeLastShape
	

	public class drawRectangle implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

			DrawPanel.draw = 3;
		}
	}// drawRechtangle
	

	public class drawOval implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

			DrawPanel.draw = 4;
		}
	}// drawOval
	

	public class drawFreeLine implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

			DrawPanel.draw = 5;
		}
	}// drawFreeLine
	

	public class drawCircle implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

			DrawPanel.draw = 6;
		}
	}// drawCircle
	

	public class clearShape implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Toolkit.getDefaultToolkit().createCustomCursor(new ImageIcon("src/gui/eraser.png").getImage(),
					new Point(0, 0), "custom cursor"));
			ImageIcon width = new ImageIcon("src/gui/erase-text.png");
			JOptionPane pane = new JOptionPane();
			String s = (String) pane.showInputDialog(null, "Insert 200, and erase it all at once !", "Set Eraser Size",
					pane.INFORMATION_MESSAGE, width, null, "");

			try {

				if (s.equals("")) {
					NotificationArea.setText(
							"\n Error>> Text field cannot be empty. Please, enter a value for eraser i.e (1,2,..)");
				}

				else {
					estroker = Integer.parseInt(s);
					if (estroker == (int) estroker) {
						DrawPanel.eraserstroker = estroker;
					}

					else {
						NotificationArea.setText(
								"\n Error>> Invalid value is entered.  Please, enter a legal value i.e (1,2,..) ");
					}
				}

			} catch (NumberFormatException e) {
				NotificationArea
						.setText("\n Error>> Invalid value is entered.  Please, enter a legal value i.e (1,2,..)");
			}

			catch (Exception e) {
				NotificationArea.setText("\n Error>> Eraser size is not selected. Please, enter a size i.e (1,2,..)");
			}

			DrawPanel.draw = 7;
		}
	}

	public class clearCanvas implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			try {
				graphicsPanel.clearCanvasServer();
			} catch (NullPointerException e) {
				NotificationArea.setText("\nError>> You are kicked from the server.");
			} catch (RemoteException e) {
				NotificationArea.setText("\nError>> Connection problem.");
			}
			openedFilePath = null;
		}

	}

	// auto save the canvas on clicking close button
	public class close implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			if (openedFilePath == null) {
				Random r = new Random();
				String num = Integer.toString(r.nextInt(100));
				openedFilePath = "testsave" + num + ".json";
				// openedFilePath = "testsave" + ".json";
			}
			graphicsPanel.saveCanvas(openedFilePath);
			//System.out.println("File Auto saved");
			System.exit(0);
		}

	}

	String selectedUsername = "";

	public class kickPlayer implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			selectedUsername = null;
			final JButton kickUser = new JButton("Select User");
			final JPopupMenu menu = new JPopupMenu("Menu");
			// Using loop add all usernames to menu list
			for (String username : updateUser) {
				if (username.equals(user.get_name())) {
					continue;
				}
				JMenuItem jMenuItem = new JMenuItem(username);
				jMenuItem.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						kickUser.setText(jMenuItem.getText());
						selectedUsername = jMenuItem.getText();
					}
				});
				menu.add(jMenuItem);
			}

			kickUser.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					menu.show(kickUser, kickUser.getWidth() / 2, kickUser.getHeight() / 2);
//                    //System.out.println(ae.getActionCommand());
//                    selectedUsername = ae.getActionCommand();
					// serverCanvas.kickUser(user.get_name(), username);
				}
			});

			String[] options = { "Ok" };
			int result = JOptionPane.showOptionDialog(null, kickUser, "Select User to Kick", JOptionPane.DEFAULT_OPTION,
					JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

			if (result == 0 && selectedUsername != null) {
				//System.out.println("Ok Cliked");
				//System.out.println(selectedUsername);
				try {
					serverCanvas.kickUser(user.get_name(), selectedUsername);
					serverCanvas.sendNotification("\nUser Kicked - " + selectedUsername);
//					NotificationArea.setText("\nUser Kicked!!");
//					NotificationArea.setText(selectedUsername);
				} catch (RemoteException e) {
					e.printStackTrace();
					//System.out.println("Error in selected username");
					NotificationArea.setText("\nError>> Selected username failed.");
				}
			}

		}

	}

	public class setText implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			// setCursor (Cursor.getPredefinedCursor (Cursor.CROSSHAIR_CURSOR));
			Point dummy = new Point(0, 0);
			String cursorName = "Cursor";
			Image cursor = new ImageIcon("src/gui/pencil.png").getImage();
			setCursor(getToolkit().createCustomCursor(cursor, dummy, cursorName));
			DrawPanel.draw = 9;
		}

	}

	public class saveFile implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			if (openedFilePath == null) {
				Random r = new Random();
				String num = Integer.toString(r.nextInt(100));
				openedFilePath = "testsave" + num + ".json";
				try {
					serverCanvas.sendNotification("\nFile Saved - " + openedFilePath);
				} catch (RemoteException e) {
					NotificationArea.setText("\nError>> Save failed, connection problem - " + openedFilePath);
					e.printStackTrace();
				}

			}
			graphicsPanel.saveCanvas(openedFilePath);
			//System.out.println("Save Button Clicked");
		}
	}

	public class sendMsgListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			String msgDet = ChatInput.getText();
			if (msgDet.isEmpty()) {
				NotificationArea.setText("\nError>> Text cannot be empty.");
			} else {
				Message msg = new Message(ClientGUI.this.user, msgDet);
				ChatInput.setText("");
				try {
					serverCanvas.sendMessage(msg);
				} catch (RemoteException e) {
					NotificationArea.setText("\nError>> Connection problem.");
				}
			}
		}
	}// sendMsgListener

	/**
	 * Save As File into File System
	 * 
	 * @author junlu
	 *
	 */
	public class saveAsFile implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			String test = "";
			String json = ".json";
			JFileChooser fc = new JFileChooser("..\\DSproject2");
			int returnVal = fc.showSaveDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				String filename = fc.getSelectedFile().getName();
				if (!filename.endsWith(".json"))
					filename += ".json";

				if (filename.length() <= 5) {
					NotificationArea.setText(
							"\nError>> Please save in the correct format. The correct format is (filename.json)");
					// //System.out.println("Error>>> Fail1 to save file");

				}

				else if (filename.length() > 5) {

					test = filename.substring(filename.length() - 5);
					if (!(json.equals(test))) {
						NotificationArea.setText(
								"\nError>> Please save in the correct format. The correct format is (filename.json)");
						// //System.out.println("Error>>> Fail2 to save file");
					}

					else {
						graphicsPanel.saveAsCanvas(filename);
						openedFilePath = filename;
						try {
							serverCanvas.sendNotification("\nFile Saved - " + filename);
						} catch (RemoteException e) {
							NotificationArea.setText("\nError>> Connection problem.");
						}
					} // end else
				} // end else if
			} // end if
		}// end actionPerformed
	}// end class

	/**
	 * Load File into Canvas
	 * 
	 * @author junlu
	 *
	 */
	public class loadFile implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			// Choose file from file system
			JFileChooser fc = new JFileChooser("..\\DSproject2");
			int returnVal = fc.showOpenDialog(null);

			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File selectedFile = fc.getSelectedFile();
				// Load file into Canvas
				graphicsPanel.loadCanvas(selectedFile.getName());
				openedFilePath = selectedFile.getName();
				try {
					serverCanvas.sendNotification("\nFile Opened - " + selectedFile.getName());
				} catch (RemoteException e) {
					NotificationArea.setText("\n Error>> Connection problem.");

				}
				//System.out.println("\nOpen File: " + selectedFile.getName());
			} else {
				NotificationArea.setText("\nError>> Fail to open file");
//            	 //System.out.println("Error>> Fail to open file");
			}
			//System.out.println("Load Button Clicked");
		}
	}

	public class setBColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.BLUE;

		}

	}

	public class setRColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.RED;

		}

	}

	public class setGColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.GREEN;

		}

	}

	public class setYColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.YELLOW;

		}

	}

	public class setOColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = orangeColor;

		}

	}

	public class setPColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.PINK;

		}

	}

	public class setCColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.CYAN;

		}

	}

	public class setMColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.MAGENTA;

		}

	}

	public class setGYColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.GRAY;

		}

	}

	public class setLGColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = Color.LIGHT_GRAY;

		}

	}

	public class setDGColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			DrawPanel.currentColor = Color.DARK_GRAY;

		}

	}

	public class setLavenderColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = LavenderColor;

		}

	}

	public class setGoldColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = goldColor;

		}

	}

	public class setBrownColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = brownColor;

		}

	}

	public class setPurpleColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = purpleColor;

		}

	}

	public class setColorsChoser implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			JColorChooser chooser = new JColorChooser();
			Color c = chooser.showDialog(null, "Choose Color Wisely !!!", Color.GREEN);// Update
			DrawPanel.currentColor = c;
			try {
				if (c == null) {
					NotificationArea.setText("\n error>> Color is not chosen. Please, choose a color.");
					DrawPanel.currentColor = Color.black;
				}
			} catch (Exception e) {

				NotificationArea.setText("\n error>> Color is not chosen. Please, choose a color.");
			}// end try/catch
		}
	}// end setColorsChoser

	public class setFontChoser implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			Font font = JFontChooser.showDialog(selectionPanel);
			DrawPanel.font = font;
		}
	}

	public class setDarkGreenColor implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			DrawPanel.currentColor = darkgreenColor;
		}
	}

	private void createGraphicsPanel(IServerCanvas serverCanvas) {
		getContentPane().setLayout(new BorderLayout(0, 0));

		ChatPanel = new JPanel();

		getContentPane().add(ChatPanel, BorderLayout.WEST);
		ChatPanel.setLayout(new BorderLayout(0, 0));

		ChatHistory = new JTextArea(23, 23);
		ChatHistory.setBorder(BorderFactory.createLineBorder(Color.pink, 3));

		ChatPanel.add(ChatHistory, BorderLayout.CENTER);
		DefaultCaret chatHistoryCaret = (DefaultCaret) ChatHistory.getCaret();
		chatHistoryCaret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		SendPanel = new JPanel();

		ChatPanel.add(SendPanel, BorderLayout.SOUTH);

		ChatInput = new JTextField();

		SendPanel.add(ChatInput);
		ChatInput.setColumns(23);
		ChatInput.addActionListener(new sendMsgListener());

		btnSend = new JButton("Send");
		btnSend.setBackground(Color.pink);
		SendPanel.add(btnSend);

		ChatHistoryPanel = new JScrollPane(ChatHistory);
		ChatPanel.add(ChatHistoryPanel, BorderLayout.CENTER);
		btnSend.addActionListener(new sendMsgListener());

		CanvasPanel = new JPanel();
		getContentPane().add(CanvasPanel);
		CanvasPanel.setLayout(new BorderLayout(0, 0));
		selectionPanel = new JPanel();
		CanvasPanel.add(selectionPanel, BorderLayout.NORTH);

		ImageIcon circle = new ImageIcon("src/gui/circle.png");
		ImageIcon rectangle = new ImageIcon("src/gui/square.png");
		ImageIcon line = new ImageIcon("src/gui/edit.png");
		ImageIcon oval = new ImageIcon("src/gui/ellipse-outline-shape-variant.png");
		ImageIcon freeline = new ImageIcon("src/gui/curved-arrow-with-broken-line.png");
		ImageIcon picker = new ImageIcon("src/gui/picker.png");
		ImageIcon textIcon = new ImageIcon("src/gui/texts.png");

		Line = new JButton(line);
		Line.setBackground(Color.white);
		Oval = new JButton(oval);
		Oval.setBackground(Color.white);
		Rectangle = new JButton(rectangle);
		Rectangle.setBackground(Color.white);
		FreeLine = new JButton(freeline);
		FreeLine.setBackground(Color.white);
		Circle = new JButton(circle);
		Circle.setBackground(Color.white);
		Text = new JButton(textIcon);
		Text.setBackground(Color.white);

		Line.addActionListener(new drawLine());
		Oval.addActionListener(new drawOval());
		Rectangle.addActionListener(new drawRectangle());
		FreeLine.addActionListener(new drawFreeLine());
		Circle.addActionListener(new drawCircle());
		Text.addActionListener(new setText());

		// Selection Panel
		selectionPanel.add(Line);
		selectionPanel.add(Oval);
		selectionPanel.add(Rectangle);
		selectionPanel.add(FreeLine);
		selectionPanel.add(Circle);
		selectionPanel.add(Text);

		selectionPanel.setBackground(Color.white);
		ColorPanel = new JPanel();
		CanvasPanel.add(ColorPanel, BorderLayout.SOUTH);
		ColorPanel.setBackground(Color.white);

		ImageIcon eraser = new ImageIcon("src/gui/eraser.png");
		ImageIcon fonty = new ImageIcon("src/gui/font-size.png");
		ImageIcon thickness = new ImageIcon("src/gui/width.png");
		ImageIcon shaperemoval = new ImageIcon("src/gui/undo (1).png");
		Eraser = new JButton(eraser);
		Eraser.setBackground(Color.white);
		Eraser.setPreferredSize(new Dimension(50, 50));
		removeShape = new JButton(shaperemoval);
		removeShape.setBackground(Color.white);
		removeShape.setPreferredSize(new Dimension(50, 50));
		ColorChoser = new JButton(picker);

		ColorChoser.setBackground(Color.white);
		ColorChoser.setPreferredSize(new Dimension(50, 50));

		FontChoser = new JButton(fonty);
		FontChoser.setBackground(Color.white);
		FontChoser.setPreferredSize(new Dimension(50, 50));

		strokeSetter = new JButton(thickness);
		strokeSetter.setBackground(Color.white);
		strokeSetter.setPreferredSize(new Dimension(50, 50));

		Blue = new JButton();
		Blue.setBackground(Color.BLUE);
		Blue.setPreferredSize(new Dimension(30, 30));

		Red = new JButton();
		Red.setBackground(Color.RED);
		Red.setPreferredSize(new Dimension(30, 30));

		Green = new JButton();
		Green.setBackground(Color.GREEN);
		Green.setPreferredSize(new Dimension(30, 30));

		Yellow = new JButton();
		Yellow.setBackground(Color.YELLOW);
		Yellow.setPreferredSize(new Dimension(30, 30));

		Orange = new JButton();
		Orange.setBackground(orangeColor);
		Orange.setPreferredSize(new Dimension(30, 30));

		Pink = new JButton();
		Pink.setBackground(Color.PINK);
		Pink.setPreferredSize(new Dimension(30, 30));

		Cyan = new JButton();
		Cyan.setBackground(Color.CYAN);
		Cyan.setPreferredSize(new Dimension(30, 30));

		Magenta = new JButton();
		Magenta.setBackground(Color.MAGENTA);
		Magenta.setPreferredSize(new Dimension(30, 30));

		Gray = new JButton();
		Gray.setBackground(Color.GRAY);
		Gray.setPreferredSize(new Dimension(30, 30));

		Dark_gray = new JButton();
		Dark_gray.setBackground(Color.darkGray);
		Dark_gray.setPreferredSize(new Dimension(30, 30));

		Light_gray = new JButton();
		Light_gray.setBackground(Color.lightGray);
		Light_gray.setPreferredSize(new Dimension(30, 30));

		Lavender = new JButton();
		Lavender.setBackground(LavenderColor);
		Lavender.setPreferredSize(new Dimension(30, 30));

		Gold = new JButton();
		Gold.setBackground(goldColor);
		Gold.setPreferredSize(new Dimension(30, 30));

		Brown = new JButton();
		Brown.setBackground(brownColor);
		Brown.setPreferredSize(new Dimension(30, 30));

		Purple = new JButton();
		Purple.setBackground(purpleColor);
		Purple.setPreferredSize(new Dimension(30, 30));

		darkGreenColor = new JButton();
		darkGreenColor.setBackground(darkgreenColor);
		darkGreenColor.setPreferredSize(new Dimension(30, 30));

		Blue.addActionListener(new setBColor());
		Red.addActionListener(new setRColor());
		Green.addActionListener(new setGColor());
		Yellow.addActionListener(new setYColor());
		Orange.addActionListener(new setOColor());
		Pink.addActionListener(new setPColor());
		Cyan.addActionListener(new setCColor());

		Magenta.addActionListener(new setMColor());
		Gray.addActionListener(new setGYColor());
		Dark_gray.addActionListener(new setDGColor());
		Light_gray.addActionListener(new setLGColor());
		Lavender.addActionListener(new setLavenderColor());
		Gold.addActionListener(new setGoldColor());
		Brown.addActionListener(new setBrownColor());
		Purple.addActionListener(new setPurpleColor());
		darkGreenColor.addActionListener(new setDarkGreenColor());
		ColorChoser.addActionListener(new setColorsChoser());
		FontChoser.addActionListener(new setFontChoser());
		strokeSetter.addActionListener(new setStroke());
		removeShape.addActionListener(new removeLastShape());

		Eraser.addActionListener(new clearShape());
		// Newfile.addActionListener(new clearCanvas());

		// ColorPanel.add(Newfile );
		ColorPanel.add(Eraser);
		ColorPanel.add(removeShape);
		ColorPanel.add(FontChoser);
		ColorPanel.add(strokeSetter);
		ColorPanel.add(ColorChoser);

		ColorPanel.add(Blue);
		ColorPanel.add(Red);
		ColorPanel.add(Yellow);
		ColorPanel.add(Orange);
		ColorPanel.add(Green);
		ColorPanel.add(Pink);
		ColorPanel.add(Cyan);
		ColorPanel.add(Magenta);
		ColorPanel.add(Gray);
		ColorPanel.add(Dark_gray);
		ColorPanel.add(Light_gray);
		ColorPanel.add(Lavender);
		ColorPanel.add(Gold);
		ColorPanel.add(Brown);
		ColorPanel.add(Purple);
		ColorPanel.add(darkGreenColor);

		String user = "NOTIFICATION !!!";
		String list = "Users' List !!!";

		UserList = new JTextArea(list, 10, 10);
		UserList.setFont(fontList);
		UserList.setForeground(Color.black);
		UserList.setBackground(Color.white);

		UserListPanel = new JScrollPane(UserList);
		UserListPanel.setBorder(BorderFactory.createLineBorder(Color.pink, 3));
		getContentPane().add(UserListPanel, BorderLayout.EAST);

		NotificationArea = new JTextArea(user, 5, 9);
		NotificationArea.setFont(font);
		NotificationArea.setForeground(Color.black);
		NotificationArea.setBackground(Color.white);
		getContentPane().add(NotificationArea, BorderLayout.NORTH);

		DefaultCaret notificationCaret = (DefaultCaret) NotificationArea.getCaret();
		notificationCaret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		NotificationPanel = new JScrollPane();
		NotificationPanel.setViewportView(NotificationArea);
		NotificationPanel.setBorder(BorderFactory.createLineBorder(Color.pink, 3));

		getContentPane().add(NotificationPanel, BorderLayout.SOUTH);
		graphicsPanel = new DrawPanel(serverCanvas, NotificationArea);

		CanvasPanel.add(graphicsPanel, BorderLayout.CENTER);

	}

	public DrawPanel getPanel() {
		return graphicsPanel;
	}

	public void disconnect() {
		serverCanvas = null;
	}

	public void exit() {
		System.exit(0);
	}

	public boolean join_popup(String username) {
		int popup_answer = JOptionPane.showConfirmDialog(null, String.format("User: %s wants to join.", username),
				"Please select", JOptionPane.YES_NO_OPTION);
		return popup_answer == JOptionPane.YES_OPTION;

	}

}
