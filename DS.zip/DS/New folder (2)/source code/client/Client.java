package client;

import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import remote.IServerCanvas;
import remote.User;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * This class retrieves a reference to the remote object from the RMI registry.
 * It invokes the methods on the remote object as if it was a local object of
 * the type of the remote interface.
 *
 */
public class Client {
	private static String serverIP = "localhost";
	private static String clientIP = "localhost";
	private static String username = "testuser";
	private static ClientGUI gui;

	public static void main(String[] args) {
		if (args.length > 0) {
			if (args.length == 3) {
				try {
					serverIP = args[0];
					clientIP = args[1];
					username = args[2];
				} catch (NumberFormatException e) {
					System.out.println("usage: java Client <serverIPAddress> <clientIPAddress> username");
					return;
				}
			} else {
				System.out.println("usage: java Client <serverIPAddress> <clientIPAddress> username");
				return;
			}
		} else {
			// FOR CONVENIENT TESTING
			username = String.format("%d", new Date().getTime());
			username = "testuser1";
		}

		try {
			IServerCanvas serverCanvas = getServerCanvas();
			User user = new User(username, clientIP);
			System.out.println("Client IP "+ clientIP);
			String permission = serverCanvas.permission_to_join(username);
			if (!permission.equals("true")) {
				System.out.println(permission);
				System.exit(0);
			}

			gui = new ClientGUI(serverCanvas, serverCanvas.is_manager(username), user);
			RemoteClientGUI remotegui = makeRemoteGUI(gui, user);

			// register client to server and load current canvas from server
			String shapesString = serverCanvas.register(user);
			JSONArray shapesList = (JSONArray) new JSONParser().parse(shapesString);
			gui.getPanel().JSONArray2ShapeArray(shapesList);

			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() { // unbind before exit
				public void run() {
					try {
//						if (!panel.isClosedByServer()) {
						serverCanvas.deregister(user);
//						}
					} catch (RemoteException e) {
//						e.printStackTrace();
						System.out.println("Client: Can't connect to Server");
					} finally {
						try {
							unbindRemoteGUI(user.get_rminame());
						} catch (RemoteException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NotBoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}));

		} catch (RemoteException e) {
			System.out.println("Failed to start the Client. Communication using RMI produced an error. Check if RMI registry is running.");
//			e.printStackTrace();
			System.exit(1);
		} catch (NotBoundException e) {
			System.out.println("Failed to start the Client. The server is not found");
			System.exit(1);
		} catch (AlreadyBoundException e) {
			System.out.println("Failed to start the Client. The same username is already bound to RMI Registry.");
			System.exit(1);
		} catch (ParseException e1) {
			System.out.println("Failed to start the Client. The canvas from the server can not be parsed");
			System.exit(1);
		}

	}

	private static RemoteClientGUI makeRemoteGUI(ClientGUI gui, User user)
			throws RemoteException, NotBoundException, AlreadyBoundException {
		System.setProperty("java.rmi.server.hostname",clientIP);

		RemoteClientGUI client = new RemoteClientGUI(gui, user);
		// Publish the remote object's stub in the registry under the name "Compute"
		Registry registry = LocateRegistry.getRegistry();
		registry.bind(user.get_rminame(), client);
		System.out.println("Client: RemoteGUI ready.");
		return client;
	}

	private static void unbindRemoteGUI(String rminame) throws RemoteException, NotBoundException {
		Registry registry = LocateRegistry.getRegistry();
		registry.unbind(rminame);
		System.out.println("Client: RemoteGUI unbinded.");

	}

	private static IServerCanvas getServerCanvas() throws RemoteException, NotBoundException {
		// Connect to the rmiregistry that is running on localhost
		Registry registry = LocateRegistry.getRegistry(serverIP);
		// Retrieve the stub/proxy for the remote math object from the registry
		IServerCanvas serverCanvas = (IServerCanvas) registry.lookup("ServerCanvas");

		System.out.println("Client: ServerCanvas connected.");
		return serverCanvas;
	}

}
