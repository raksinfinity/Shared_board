package client;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import gui.Shape;

public class ClientCanvas {

	private Map<Integer, Shape> content;

	public ClientCanvas() {
		content = new HashMap<Integer, Shape>();
	}

	public void add(Shape shape, int id) {
		content.put(id, shape);
		System.out.println("Client: " + content.toString());
	}

	public Shape remove(int id) {
		// return the removed Shape or null
		return this.content.remove(id);

	}

	public Set<Integer> keySet() {
		return content.keySet();
	}

	public String toString() {
		Gson gson = new GsonBuilder().create();
		String result = gson.toJson(content);
		return result;
	}

}
