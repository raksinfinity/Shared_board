package client;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import remote.IRemoteClientGUI;
import remote.Message;
import remote.User;
import gui.Shape;

public class RemoteClientGUI extends UnicastRemoteObject implements IRemoteClientGUI {
	private ClientGUI gui;
	private DrawPanel panel;
	private User user;

	public RemoteClientGUI(ClientGUI gui, User user) throws RemoteException {
		this.gui = gui;
		this.panel = gui.getPanel();
		this.user = user;
	}

	@Override
	public synchronized void draw(Shape shape, int id) throws RemoteException {
		panel.draw(shape, id);
	}

	@Override
	public synchronized String get_content() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public synchronized void clearCanvas() throws RemoteException {
		panel.clearCanvas();
	}

	@Override
	public synchronized void removeLastShape() throws RemoteException {
		panel.removeLastShape();
	}

	@Override
	public synchronized void closeCanvas(String info) throws RemoteException {
		panel.disconnect();
		gui.disconnect();
		panel.closeCanvas(info);

	}

	@Override
	public synchronized void updateUsersList(ArrayList<String> usersList) throws RemoteException {
		//System.out.println(usersList);
		gui.setUpdateUser(usersList);

	}

	@Override
	public synchronized void recvMessage(Message msg) throws RemoteException {
		//System.out.println(msg.toString());
		gui.setChatlog(msg);
	}

	@Override
	public synchronized boolean join_popup(String username) throws RemoteException {

		return gui.join_popup(username);
	}

	@Override
	public synchronized void recvNotification(String notification) throws RemoteException {
		//System.out.println(notification);
		gui.setNotification(notification);
	}

}
