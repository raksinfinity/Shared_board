package client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;

import gui.Circle;
import gui.Eraser;
import gui.FreeLine;
import gui.Line;
import gui.Oval;
import gui.Rectangle;
import gui.Shape;
import gui.Text;
import remote.IServerCanvas;

public class DrawPanel extends JPanel {
	public static ArrayList<Shape> shapes;
	public static Font font = new Font("Verdana", Font.BOLD, 12);
	public static Font testfont = new Font("Verdana", Font.BOLD, 12);
	public static String text;
	public int x;
	public int y;
	public int x0;
	public int y0;
	public int x1;
	public int y1;
	public static double draw;
	public static int stroke;
	public Shape currentShape;
	public static Color currentColor;
	public static int eraserstroker;
	private FreeLine currentFreeLine;
	private Eraser currentFreeEraser;
	private IServerCanvas serverCanvas;
//	private ClientCanvas clientCanvas;
//	private boolean closedByServer;
	private Color eraser_color = Color.white;
	private JTextArea NotificationArea;

	public DrawPanel(IServerCanvas serverCanvas, JTextArea NotificationArea) {
		this.NotificationArea = NotificationArea;
		this.serverCanvas = serverCanvas;
//		this.clientCanvas = new ClientCanvas();
		shapes = new ArrayList<Shape>();
//		closedByServer = false;

		currentShape = null;
		currentColor = new Color(0, 0, 0);
		setBackground(Color.WHITE);

		MouseHandler mouseHandler = new MouseHandler();
		addMouseListener(mouseHandler);
		addMouseMotionListener(mouseHandler);
	}

	@Override
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		java.awt.Graphics2D g2 = (java.awt.Graphics2D) g;
		for (int si=0; si<shapes.size(); si++) {
			shapes.get(si).draw(g2);
		}

		if (currentShape != null) {
			currentShape.draw(g2);
		}

	}

	/**
	 * Save As Canvas Convert ArrayList to Json and save it to File System
	 */
	public void saveAsCanvas(String filePath) {
		String saveJson = new Gson().toJson(shapes);
		
		try {
			//System.out.println("File Saved");
			FileWriter writer = new FileWriter(filePath);
			writer.write(saveJson);
			writer.close();
		} catch (JsonIOException | IOException e) {
			NotificationArea.setText("\nError>> Failed to write Json to file.");

		}
	}

	/**
	 * Save Canvas Convert ArrayList to Json and save it to File System
	 */
	public void saveCanvas(String openedFilePath) {
		String filePath;
		if (openedFilePath == null) {
			Random r = new Random();
			String num = Integer.toString(r.nextInt(100));
			filePath = "testsave" + num + ".json";
		} else {
			filePath = openedFilePath;
		}

		String saveJson = new Gson().toJson(shapes);
		try {
			//System.out.println("File Saved");
			FileWriter writer = new FileWriter(filePath);
			writer.write(saveJson);
			writer.close();
		} catch (JsonIOException | IOException e) {
			NotificationArea.setText("\nError>> Failed to write Json to file.");

		}
	}

	public void JSONArray2ShapeArray(JSONArray shapesList) {
		for (Object shape : shapesList) {
			Shape shapeObj = null;
			JSONObject jsonShape = (JSONObject) shape;
			String type = (String) jsonShape.get("type");
			String text = (String) jsonShape.get("text");

			JSONObject parent = (JSONObject) jsonShape.get("font");
			String name = (String) parent.get("name");
			int style = (int) ((Long) parent.get("style")).intValue();
			int size = (int) ((Long) parent.get("size")).intValue();

			Font testfont = new Font(name, style, size);

			int red = (int) ((Long) jsonShape.get("r")).intValue();
			int green = (int) ((Long) jsonShape.get("g")).intValue();
			int blue = (int) ((Long) jsonShape.get("b")).intValue();
			int shapeStroke = (int) ((Long) jsonShape.get("st")).intValue();

			Color cColor = new Color(red, green, blue);

			int x0 = (int) ((Long) jsonShape.get("x1")).intValue();
			int y0 = (int) ((Long) jsonShape.get("y1")).intValue();
			int x1 = (int) ((Long) jsonShape.get("x2")).intValue();
			int y1 = (int) ((Long) jsonShape.get("y2")).intValue();

			if (type.equals("Oval")) {
				shapeObj = new Oval(x0, y0, x1, y1, shapeStroke, cColor, text, testfont);

			} else if (type.equals("Line")) {
				shapeObj = new Line(x0, y0, x1, y1, shapeStroke, cColor, text, testfont);

			} else if (type.equals("Rectangle")) {
				shapeObj = new Rectangle(x0, y0, x1, y1, shapeStroke, cColor, text, testfont);

			} else if (type.equals("Circle")) {
				shapeObj = new Circle(x0, y0, x1, y1, shapeStroke, cColor, text, testfont);

			} else if (type.equals("Text")) {
				shapeObj = new Text(x0, y0, x1, y1, shapeStroke, cColor, text, testfont);

			} else if (type.equals("FreeLine")) {
				JSONArray xjArray = (JSONArray) jsonShape.get("X");
				ArrayList<Integer> Xlist = JSONArray2ArrayList(xjArray);

				JSONArray yjArray = (JSONArray) jsonShape.get("Y");
				ArrayList<Integer> Ylist = JSONArray2ArrayList(yjArray);

				shapeObj = new FreeLine(Xlist, Ylist, shapeStroke, cColor, text, testfont);
			} else if (type.equals("Eraser")) {
				JSONArray xjArray = (JSONArray) jsonShape.get("X");
				ArrayList<Integer> Xlist = JSONArray2ArrayList(xjArray);

				JSONArray yjArray = (JSONArray) jsonShape.get("Y");
				ArrayList<Integer> Ylist = JSONArray2ArrayList(yjArray);

				shapeObj = new Eraser(Xlist, Ylist, shapeStroke, cColor, text, testfont);
			} // end else if

			shapes.add(shapeObj);
			try {
				addShapeServer(shapeObj);
			} catch (RemoteException e) {
				NotificationArea.setText("\nError>> Connection problem.");
				e.printStackTrace();
			} catch (NullPointerException e) {
				NotificationArea.setText("\nError>> File not found.");
				e.printStackTrace();
			}

		} // end for
	}// JSONArray2ShapeArray

	public void loadCanvas(String filePath) {

		// JSON parser object to parse read file
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader(filePath)) {
			// Clean the canvas
//    		shapes.clear();
			clearCanvasServer();

			// Read JSON file
			Object obj = jsonParser.parse(reader);

			JSONArray shapesList = (JSONArray) obj;
			JSONArray2ShapeArray(shapesList);
			repaint();

		} catch (FileNotFoundException e) {
			NotificationArea.setText("\nError>> File not found.");
		} catch (IOException e) {
			NotificationArea.setText("\nError>> File cannot be read.");
		} catch (ParseException e) {
			NotificationArea.setText("\nError>> File cannot be parsed.");
		}

	}// end loadCanvas

	/**
	 * Convert JSONArray to ArrayList
	 * 
	 * @param jArray
	 * @return list
	 */
	static private ArrayList<Integer> JSONArray2ArrayList(JSONArray jArray) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (Object cor : jArray) {
//			//System.out.println("Y: "+ ((Integer) ((Long) cor).intValue()));
			list.add(((Integer) ((Long) cor).intValue()));
		}
		return list;
	}

	private class MouseHandler extends MouseAdapter implements MouseMotionListener {

		public void mousePressed(MouseEvent event) {

			x0 = event.getX();
			y0 = event.getY();

			if (draw == 2) {

				currentShape = new Line(x0, y0, x0, y0, stroke, currentColor, "", font);
			}

			else if (draw == 3) {

				currentShape = new Rectangle(x0, y0, x0, y0, stroke, currentColor, "", font);

			}

			else if (draw == 4) {

				currentShape = new Oval(x0, y0, 75, 100, stroke, currentColor, "", font);
			}

			else if (draw == 5) {
				currentFreeLine = new FreeLine(stroke, currentColor, font);

			}

			else if (draw == 6) {

				currentShape = new Circle(x0, y0, 100, 100, stroke, currentColor, "", font);
			}

			else if (draw == 11) {

//				ClearLastShape();
				try {
					removeLastShapeServer();
				} catch (NullPointerException e) {
					NotificationArea.setText("\nError>> Connection problem.");
				} catch (RemoteException e) {
					NotificationArea.setText("\nError>> Connection problem.");

				}
			}

			else if (draw == 7) {
				currentFreeEraser = new Eraser(eraserstroker, eraser_color, font);

			}

			else if (draw == 8) {

//				ClearCanvas();
				try {
					clearCanvasServer();
				} catch (NullPointerException e) {
					NotificationArea.setText("\nError>> Connection problem.");
				} catch (RemoteException e) {
					NotificationArea.setText("\nError>> Connection problem.");

				}
			}

		}

		public void mouseReleased(MouseEvent event) {
			x1 = event.getX();
			y1 = event.getY();

			if (draw == 9) {
				ImageIcon pageText = new ImageIcon("src/gui/text.png");

				JOptionPane paneText = new JOptionPane();
				text = (String) paneText.showInputDialog(null, "Write Something, Please!", "Text Editor",
						paneText.INFORMATION_MESSAGE, pageText, null, "");
				try {
					if (text.equals(""))
						ClientGUI.NotificationArea.setText("\nError>> Text field cannot be empty. Please, insert text!");
					else
						currentShape = new Text(x0, y0, x1, y1, stroke, currentColor, text, font);
				}

				catch (Exception e) {
					//System.out.println("");
				}

			}

			if (draw == 5) {
				currentShape = currentFreeLine;
			}

			if (draw == 7) {
				currentShape = currentFreeEraser;
			}

			if (currentShape != null) {

				currentShape.setX2(event.getX());
				currentShape.setY2(event.getY());

//				shapes.add(currentShape);
				try {
					addShapeServer(currentShape);
				} catch (NullPointerException e) {
					NotificationArea.setText("\nError>> Connection problem.");
				} catch (RemoteException e) {
					NotificationArea.setText("\nError>> Connection problem.");

				}
				currentShape = null;

//				repaint();

			}
		}

		public void mouseMoved(MouseEvent event) {

		}

		public void mouseDragged(MouseEvent event) {
			x = event.getX();
			y = event.getY();

			if (draw == 5) {// freeline

				currentFreeLine.X.add(x);
				currentFreeLine.Y.add(y);
				currentShape = currentFreeLine;

			}

			if (draw == 7) {// Eraser

				currentFreeEraser.X.add(x);
				currentFreeEraser.Y.add(y);
				currentShape = currentFreeEraser;

			}

			if (currentShape != null) {

				currentShape.setX2(event.getX());
				currentShape.setY2(event.getY());
				repaint();

			}

		}

	}

	// called by RemoteClientGUI
	public void  draw(Shape co, int id) {
//		clientCanvas.add(co, id);
		shapes.add(co);
		//System.out.println("Client: draw on canvas " + co.toString());
		//System.out.println("Client: now has %d obj " + shapes.size());

		repaint();
	}

	public void saveAsPicture() {
		BufferedImage bImg = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D cg = bImg.createGraphics();
		this.paintAll(cg);
		try {
			if (ImageIO.write(bImg, "png", new File("./output_image.png"))) {
				//System.out.println("-- saved as picture");
			}
		} catch (IOException e) {
			NotificationArea.setText("\nError>> Picture cannot be saved.");

		}
	}

	// called by RemoteClientGUI
	public void disconnect() {
		serverCanvas = null;
	}
	// called by RemoteClientGUI
	public void clearCanvas() {
			shapes.clear();
		repaint();
	}
	// called by RemoteClientGUI
	public void removeLastShape() {
		if (DrawPanel.shapes.size() > 0)
			DrawPanel.shapes.remove(DrawPanel.shapes.size() - 1);

		repaint();
	}

	public void addShapeServer(Shape co) throws RemoteException, NullPointerException {
		//System.out.println("Client: Send to server: " + co.toString());
		serverCanvas.add(co);
	}

	public void removeLastShapeServer() throws RemoteException, NullPointerException {
		serverCanvas.removeLastShape();
	}

	public void clearCanvasServer() throws RemoteException, NullPointerException {
		serverCanvas.clearCanvas();
	}

	public void closeCanvas(String info) {
//		JOptionPane.showMessageDialog(null, info, "Message", JOptionPane.INFORMATION_MESSAGE);
		NotificationArea.setText("\n"+info);

	}

//	public ClientCanvas get_data() {
//		return clientCanvas;
//	}

}
